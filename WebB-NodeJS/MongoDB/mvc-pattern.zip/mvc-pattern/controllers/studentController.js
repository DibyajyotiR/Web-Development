//Student model imported here only
const Student = require('../models/student');    //here Student is a model

//methods are handle here 
//data created here only

//createStudent is a method,which is handle the data
exports.createStudent=async(req,res)=>{
    Student.create({
        name:"Jaesun",
        age:28,
        rollNo:"474ABS",
        subject:"ReactJS"
    })
}
exports.getStudents=async(req,res)=>{
    const student=await Student.find()
    res.json(student)  //api re data send pain json method use kruchu
}
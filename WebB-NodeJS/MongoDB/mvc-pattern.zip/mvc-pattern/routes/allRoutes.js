const express = require('express');
const router=express.Router()
const studentRoutes = require('../routes/studentRoutes');

router.use('/students',studentRoutes)
module.exports=router